package com.example.dermatologistcare.ui.login.data.repositories

class LoginRepository {
}