package com.example.dermatologistcare.ui.login.data.service.retrofit

import retrofit2.http.Body
import retrofit2.http.POST

//interface ApiService {
//    @POST("/register")
//    suspend fun register(@Body request: RegisterRequest): RegisterResponse
//
//    @POST("/verify-otp")
//    suspend fun verifyOtp(@Body request: VerifyOtpRequest): VerifyOtpResponse
//}
